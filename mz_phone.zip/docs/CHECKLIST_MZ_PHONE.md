# Checklist MZ Phone

Este checklist e o guia de continuidade do `mz_phone`. Ele foi criado a partir da leitura do estado atual do workspace, sem uso de historico Git e sem alterar runtime.

## Regras de trabalho

- [ ] Nao tocar em `mz_core` durante fases do telefone.
- [ ] Nao reescrever `mz_phone` inteiro.
- [ ] Nao copiar codigo runtime do `celular`; usar somente como referencia visual/UX.
- [ ] Manter camera, galeria, `mz_phone_server`, RealEstate, mensagens, chamadas e notas operando.
- [ ] Cada fase deve ter escopo fechado, lista de arquivos afetados e validacao manual definida antes de editar runtime.
- [ ] Marcar item como concluido somente depois de implementado e validado.

## Inventario atual

- [x] `mz_phone` e um resource FiveM com NUI modular em `web/apps/*.js`.
- [x] Apps registrados por `registerApp` e renderizados via `AppRegistry`.
- [x] Estado central fica em `web/app.js`, com `DEFAULT_PHONE_STATE`, `PhoneApp`, `PhoneMedia` e listeners.
- [x] Contratos de normalizacao ficam em `web/app_contract.js`.
- [x] API NUI fica em `web/api.js` e chama `RegisterNUICallback` em `client/nui.lua`.
- [x] Servidor Lua usa `server/callbacks.lua`, `server/service.lua` e `server/repository.lua`.
- [x] `mz_phone_server` e um servico Node/Express externo para assets e upload.
- [x] `celular` e uma referencia separada, monolitica e asset-heavy.

## Padrao de apps

- [ ] Todos os apps devem seguir o contrato documentado em `PADRAO_APPS.md`.
- [ ] Novos apps devem ser adicionados em `web/apps/<id>.js`, `web/css/apps/<id>.css`, `web/index.html`, `fxmanifest.lua` e `shared/apps.lua`.
- [ ] Estado persistente deve passar por `AppContract` quando houver normalizacao.
- [ ] Estado transiente de tela deve ficar no `PhoneApp`/`DEFAULT_PHONE_STATE`, com nomes prefixados pelo app.
- [ ] Apps nao devem chamar diretamente eventos Lua; devem usar `PhoneAPI`.
- [ ] Apps nao devem montar fetch manual para `https://resource/endpoint` fora de `PhoneAPI`.

## Media, camera e galeria

- [ ] O fluxo de picker deve sempre passar por `PhoneMedia.openGalleryForResult` ou `PhoneMedia.openCameraForResult`.
- [ ] `GalleryApp.onOpen` deve carregar a mesma galeria usada pelo app Galeria normal.
- [ ] `GalleryApp.selectPhoto` deve buscar em `AppContract.gallery.get(state)`.
- [ ] A API deve aceitar payloads de galeria como array direto, `photos`, `items`, `gallery`, `data.*` ou `result.*` quando aplicavel.
- [ ] O resultado de media deve conter `id`, `url`, `imageUrl`, `thumbnailUrl`, `source` e `type`.
- [ ] Para RealEstate, o ID retornado deve ser o `photo.id` real da tabela `mz_phone_gallery`.
- [ ] Nao anexar automaticamente foto de camera em novas alteracoes ate a fase dedicada.

## RealEstate

- [ ] Manter integracao com exports do `mz_realestate`; nao mover regras para `mz_phone`.
- [ ] Manter validacao de propriedade da foto no servidor antes de anexar.
- [ ] Separar correcoes de fluxo de media de melhorias visuais.
- [ ] Evitar aumentar `web/apps/realestate.js` sem plano de divisao ou helpers internos.
- [ ] Definir teste manual para listar, criar, editar, anexar foto, definir capa e remover foto.

## `mz_phone_server`

- [ ] Usar apenas como servidor externo de assets/upload, nunca como resource FiveM.
- [ ] Manter token forte em `.env`, nunca em repositorio.
- [ ] Validar `/health` e `/api/mz-phone/upload` quando mexer em camera/upload.
- [ ] Manter `uploads/` fora do repositorio.
- [ ] Conferir `PUBLIC_BASE_URL` quando fotos salvam mas URL nao abre.

## Referencia `celular`

- [ ] Usar assets, icones, sons, fontes e ideias de UX somente depois de conferir caminho, licenca interna e compatibilidade.
- [ ] Nao copiar `apps.js`, `server.js`, `client.lua`, `index.html` ou upload PHP como base runtime.
- [ ] Priorizar migracoes pequenas: wallpapers, icones, sons, depois componentes visuais.

## Validacao por fase

- [ ] Rodar validacao estatica somente quando houver edicao runtime.
- [ ] Testar abrir/fechar telefone.
- [ ] Testar Galeria standalone.
- [ ] Testar Galeria picker a partir de RealEstate.
- [ ] Testar Camera standalone.
- [ ] Testar Mensagens com texto e media.
- [ ] Testar Chamadas recebidas, aceitas, recusadas e encerradas.
- [ ] Testar Notas e Contatos.

## Ordem recomendada

1. Estabilizar contrato Media/Camera/Galeria.
2. Blindar RealEstate em cima desse contrato.
3. Padronizar apps existentes sem mudar comportamento.
4. Avaliar migracao visual controlada da referencia `celular`.
5. Planejar novos apps ou recursos depois que o core estiver estavel.
