# Padrao Media, Camera e Galeria

Este documento define o contrato de midia do `mz_phone`, especialmente para Camera, Galeria e pickers usados por outros apps.

## Objetivo

Ter um unico caminho confiavel para:

- Abrir Galeria como app normal.
- Abrir Galeria como picker para outro app.
- Abrir Camera como app normal.
- Abrir Camera como origem de foto para outro app.
- Retornar uma foto normalizada para quem pediu.

## Fonte de verdade

A fonte de verdade da galeria e a tabela `mz_phone_gallery`, exposta pelo servidor Lua:

```txt
Repository.GetGalleryPhotos
Service.GetGallery
TriggerClientEvent('mz_phone:client:receiveGallery', photos)
SendNUIMessage({ action = 'receiveGallery', photos = data })
PhoneAPI.onReceiveGallery
phoneState.gallery
AppContract.gallery.get(state)
```

O app Galeria standalone e o modo picker devem renderizar a mesma lista: `AppContract.gallery.get(state)`.

## Formato de foto

Formato normalizado esperado pelo frontend:

```js
{
  id: 123,
  image_url: "https://...",
  thumbnail_url: "",
  caption: "",
  source: "camera",
  favorite: false,
  created_at: "2026-06-14 12:00:00",
  metadata: {}
}
```

Alias aceitos no `AppContract.gallery`:

- `id`, `photoId`, `photo_id`
- `image_url`, `imageUrl`, `url`
- `thumbnail_url`, `thumbnailUrl`
- `created_at`, `createdAt`

## Payloads aceitos

O frontend deve aceitar:

- array direto
- `{ photos: [...] }`
- `{ items: [...] }`
- `{ gallery: [...] }`
- `{ data: { photos: [...] } }`
- `{ data: { items: [...] } }`
- `{ result: { photos: [...] } }`
- `{ result: { items: [...] } }`

O retorno atual do client Lua usa `photos`, e o RealEstate tambem pode emitir `receiveRealEstateAction` com `result.photos`.

## PhoneMedia

`PhoneMedia` em `web/app.js` e o dispatcher oficial de picker.

Contrato de abertura:

```js
window.PhoneMedia.openGalleryForResult({
  purpose: "realestate_listing_photo",
  returnApp: "realestate",
  context: {
    listingCode: "ABC123",
  },
  returnState: {
    realEstateView: "form",
  },
});
```

Campos:

- `kind`: definido internamente como `gallery` ou `camera`.
- `purpose`: identifica a acao esperada pelo app de destino.
- `returnApp`: app que recebera `applyMediaResult`.
- `context`: dados de dominio, como `listingCode`.
- `returnState`: estado a restaurar antes de despachar o resultado.

## Resultado de midia

`completeMediaRequest(photo, source)` normaliza para:

```js
{
  id: 123,
  url: "https://...",
  imageUrl: "https://...",
  thumbnailUrl: "",
  caption: "",
  type: "image",
  source: "gallery"
}
```

Para RealEstate, `id` precisa ser o ID real da `mz_phone_gallery`, pois `attachRealEstateGalleryPhoto` valida posse no servidor antes de chamar o `mz_realestate`.

## Galeria standalone

Ao abrir `gallery` normalmente:

1. `GalleryApp.onOpen` limpa selecao.
2. Define `galleryPicker` como false, exceto se o estado ou params indicarem picker.
3. Chama `PhoneAPI.getGallery()`.
4. Renderiza `AppContract.gallery.get(state)`.
5. Clique em foto abre viewer.

## Galeria picker

Ao abrir via `PhoneMedia.openGalleryForResult`:

1. `beginMediaRequest("gallery", options)` salva request ativa.
2. Estado recebe `galleryPicker: true`.
3. `openApp("gallery", { picker: true })` abre o app.
4. `GalleryApp.onOpen` tambem chama `PhoneAPI.getGallery()`.
5. `GalleryApp.selectPhoto(photoId)` busca em `AppContract.gallery.get(state)`.
6. `PhoneMedia.complete(photo, "gallery")` restaura o app de origem.
7. `dispatchMediaResult` chama `<ReturnApp>.applyMediaResult(result, request)`.

## Camera standalone

Ao abrir `camera` normalmente:

1. `CameraApp.onOpen` limpa estado de camera.
2. `CameraApp.openCameraMode()` chama `PhoneAPI.openCameraMode`.
3. Client Lua inicia o modo camera.
4. Ao salvar, `Service.SaveCameraPhoto` registra em `mz_phone_gallery`.
5. Servidor envia `receiveGallery` e `cameraPhotoSaved`.
6. Se nao ha request ativa, o fluxo volta para Galeria.

## Camera como picker

Ao abrir via `PhoneMedia.openCameraForResult`:

1. `beginMediaRequest("camera", options)` salva request ativa.
2. `openApp("camera", { mediaRequest: true })` abre o app.
3. `CameraApp.openCameraMode` envia `forResult`, `purpose` e `restoreApp`.
4. Ao salvar foto, `cameraPhotoSaved` chama `PhoneMedia.complete(data.photo, "camera")`.
5. O app de destino recebe o mesmo formato normalizado de media.

## RealEstate

O RealEstate deve anexar foto assim:

```txt
RealEstateApp.openGalleryPicker
PhoneMedia.openGalleryForResult
GalleryApp.selectPhoto
PhoneMedia.complete
RealEstateApp.applyMediaResult
PhoneAPI.attachRealEstateGalleryPhoto(listingCode, galleryPhotoId)
Service.AttachGalleryPhotoToRealEstateListing
Repository.GetGalleryPhotoById
validacao owner_citizenid
export mz_realestate:AttachPhotoToListingFromPhone
```

Regras:

- O frontend nao deve confiar apenas em URL para anexar.
- O servidor deve continuar validando `owner_citizenid`.
- `galleryPhotoId` deve ser numerico e positivo.
- `photo_not_owned` e `photo_not_found` sao erros esperados e devem aparecer como mensagem de dominio.

## Falhas comuns

- Picker abre com `galleryPicker: true`, mas `state.gallery` esta vazio porque `getGallery` nao foi chamado.
- Payload de galeria vem aninhado em `data` ou `result` e nao e normalizado.
- Foto tem URL, mas nao tem `id`; RealEstate nao consegue anexar com seguranca.
- App de retorno nao implementa `applyMediaResult`.
- `returnState` restaura uma tela antiga e apaga estado necessario para anexar.

## Validacao manual minima

- Abrir Galeria standalone e ver fotos.
- Atualizar Galeria e confirmar que a lista nao some.
- Abrir RealEstate, editar anuncio e clicar em "Adicionar da Galeria".
- Confirmar que as mesmas fotos aparecem no picker.
- Selecionar foto e confirmar que `attachRealEstateGalleryPhoto` recebe `galleryPhotoId`.
- Confirmar que a foto aparece no anuncio.
- Cancelar picker e confirmar retorno ao formulario.
