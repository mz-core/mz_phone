# Plano RealEstate App

Este plano cobre a continuidade do app Imoveis/RealEstate dentro do `mz_phone`.

## Estado atual observado

O app `web/apps/realestate.js` concentra:

- Listagem publica de anuncios.
- Detalhe publico.
- Area do corretor.
- Criacao e edicao de anuncio.
- Gerenciamento de fotos.
- Picker de galeria antigo/local e fluxo novo por `PhoneMedia`.
- Chamadas, mensagens e GPS a partir do anuncio.

O servidor Lua integra com `mz_realestate` por exports em `server/service.lua`. O `mz_phone` nao deve assumir regra de negocio de propriedade; ele deve apenas normalizar payloads e chamar os exports.

## Contratos externos atuais

Exports esperados de `mz_realestate`:

- `ListPublicListings`
- `GetActiveListings`
- `GetListingByCode`
- `GetPhoneBrokerAccess`
- `ListPhoneAdvertisableProperties`
- `ListMyListings`
- `GetMyListingFromPhone`
- `CreateListingFromPhone`
- `UpdateListingFromPhone`
- `SetListingStatusFromPhone`
- `ListListingPhotosFromPhone`
- `AttachPhotoToListingFromPhone`
- `SetListingPrimaryPhotoFromPhone`
- `RemoveListingPhotoFromPhone`

O `mz_phone` deve continuar tratando `realestate_unavailable`, `broker_required`, `listing_not_found`, `photo_not_owned`, `invalid_photo` e `rate_limited`.

## Riscos atuais

- `realestate.js` esta grande e mistura UI, estado, validacao, midia e acoes de servidor.
- Existem dois conceitos de picker: modal interno `realEstatePhotoPickerOpen` e picker via `PhoneMedia`.
- O fluxo de foto depende de `photo.id`, nao apenas de `imageUrl`.
- O app depende de estado restaurado corretamente apos sair para Galeria/Camera.
- Erros em media podem parecer erro de RealEstate, embora a origem seja contrato de Galeria.

## Fase 1: estabilizar midia

Objetivo: garantir que RealEstate use o contrato de `PhoneMedia` de forma previsivel.

Arquivos provaveis:

- `web/app.js`
- `web/api.js`
- `web/app_contract.js`
- `web/apps/gallery.js`
- `web/apps/realestate.js`
- `client/nui.lua`
- `server/callbacks.lua`
- `server/service.lua`

Regras:

- Nao mexer no comportamento da camera standalone.
- Nao anexar automaticamente foto de camera ate a decisao explicita da fase.
- Garantir que Galeria picker e Galeria normal carreguem a mesma lista.
- Garantir que `applyMediaResult` receba `result.id`.
- Manter validacao server-side em `AttachGalleryPhotoToRealEstateListing`.

Aceite:

- Foto tirada pela camera aparece na Galeria standalone.
- A mesma foto aparece em "Adicionar da Galeria".
- Selecionar foto anexa ao anuncio usando `galleryPhotoId`.
- Cancelar picker retorna ao formulario sem perder dados.

## Fase 2: blindar acoes de fotos do anuncio

Objetivo: deixar foto do anuncio resiliente a refresh, capa e remocao.

Itens:

- Padronizar loading separado para lista, formulario e fotos.
- Garantir refresh apos anexar, definir capa e remover.
- Confirmar que `result.photos` atualiza `realEstateSelectedListing.photos`.
- Melhorar mensagens de erro de dominio.

Aceite:

- Anexar foto atualiza o card de fotos sem fechar indevidamente o app.
- Definir capa atualiza badge e cover.
- Remover foto atualiza lista.
- Erros de permissao/posse aparecem claros.

## Fase 3: reduzir complexidade de `realestate.js`

Objetivo: diminuir risco sem reescrever.

Opcoes conservadoras:

- Extrair helpers puros dentro do mesmo arquivo primeiro.
- Separar renderizadores por secao somente se o `fxmanifest` e `index.html` forem atualizados com ordem clara.
- Manter `window.RealEstateApp` como API publica do app.
- Preservar nomes de estado existentes para evitar regressao.

Possiveis separacoes futuras:

- `realestate_helpers.js`
- `realestate_render.js`
- `realestate_actions.js`

Essa fase so deve ocorrer depois da fase 1 e 2 estarem validadas.

## Fase 4: polimento visual

Objetivo: melhorar UX usando referencia `celular` somente como inspiracao.

Itens:

- Melhorar cards de listagem e detalhe sem mudar contrato.
- Avaliar icone/app visual de Imoveis.
- Melhorar empty states, loading e botoes de acao.
- Revisar responsividade dentro da moldura do telefone.

Aceite:

- Listagem publica legivel.
- Area do corretor clara.
- Formulario nao perde dados entre navegacoes.
- Fotos do anuncio funcionam em mobile/NUI.

## Fase 5: funcionalidades futuras

Somente depois de estabilizar:

- Filtros por bairro/cidade/preco.
- Favoritos/salvos.
- Compartilhar anuncio por mensagem.
- Rota/GPS mais rica.
- Galeria dedicada por anuncio.
- Draft local de anuncio.

## Validacao manual completa

- Abrir app Imoveis.
- Alternar abas Todos, Venda e Aluguel.
- Abrir detalhe de anuncio.
- Chamar corretor.
- Enviar mensagem ao corretor.
- Marcar GPS.
- Abrir area do corretor.
- Criar anuncio.
- Editar anuncio.
- Adicionar foto da Galeria.
- Tirar foto pela Camera e confirmar que aparece na Galeria.
- Definir foto principal.
- Remover foto.
- Pausar, ativar e arquivar anuncio.

## Primeira fase recomendada

A primeira fase deve ser `Fase 1: estabilizar midia`, porque ela e a base para RealEstate, Settings, Contacts e Messages. Qualquer melhoria visual ou refatoracao antes disso aumenta o risco de regressao.
